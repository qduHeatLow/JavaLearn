declare module '*.vue' {
  import Vue from 'vue';
  export default Vue;
}

declare module 'is-promise'

declare module '@/config.json'